import java.util.Scanner;

public class OnlineExaminationSystem{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Online Exam!");

        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.println("Hello, " + name + "! Let's begin the exam.");
        int score = 0;

        // Sample questions and answers
        String[] questions = {
                "1. What is the capital of France?\n(a) Paris\n(b) London\n(c) Berlin",
                "2. What is 2 + 2?\n(a) 3\n(b) 4\n(c) 5",
                // Add more questions here
        };

        String[] correctAnswers = {"a", "b"}; // Answers for each question

        for (int i = 0; i < questions.length; i++) {
            System.out.println(questions[i]);
            System.out.print("Your answer: ");
            String userAnswer = scanner.nextLine().toLowerCase();

            if (userAnswer.equals(correctAnswers[i])) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect!");
            }
        }

        System.out.println("Congratulations, " + name + "!");
        System.out.println("Your score: " + score + " out of " + questions.length);

        scanner.close();
    }
}

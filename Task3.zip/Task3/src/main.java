import java.util.Scanner;
import java.util.ArrayList;

class User {
    private int userId;
    private int pin;

    public User(int userId, int pin) {
        this.userId = userId;
        this.pin = pin;
    }

    public int getUserId() {
        return userId;
    }

    public int getPin() {
        return pin;
    }
}

class ATM {
    private User currentUser;
    private ArrayList<String> transactionHistory;

    public ATM() {
        transactionHistory = new ArrayList<>();
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter PIN: ");
        int pin = scanner.nextInt();

        if (authenticateUser(userId, pin)) {
            System.out.println("Authentication successful. Welcome!");
            showMainMenu();
        } else {
            System.out.println("Authentication failed. Exiting.");
        }
    }

    private boolean authenticateUser(int userId, int pin) {
        // Replace this with your actual authentication logic.
        // For simplicity, we'll use a hardcoded user here.
        User user = new User(123456, 7890);
        if (user.getUserId() == userId && user.getPin() == pin) {
            currentUser = user;
            return true;
        }
        return false;
    }

    private void showMainMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMain Menu");
            System.out.println("1. View Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Transfer");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    viewTransactionHistory();
                    break;
                case 2:
                    performWithdrawal();
                    break;
                case 3:
                    performTransfer();
                    break;
                case 4:
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private void viewTransactionHistory() {
        if (transactionHistory.isEmpty()) {
            System.out.println("Transaction history is empty.");
        } else {
            System.out.println("\nTransaction History:");
            for (String transaction : transactionHistory) {
                System.out.println(transaction);
            }
        }
    }

    private void performWithdrawal() {
        // Implement withdrawal logic here.
        // Update the transaction history accordingly.
        // You can ask the user for the withdrawal amount, check balance, etc.
        // For simplicity, we'll just add a sample transaction to the history.
        transactionHistory.add("Withdrawal: $100");
        System.out.println("Withdrawal successful.");
    }

    private void performTransfer() {
        // Implement transfer logic here.
        // Update the transaction history accordingly.
        // You can ask the user for the transfer amount, recipient's account, etc.
        // For simplicity, we'll just add a sample transaction to the history.
        transactionHistory.add("Transfer: $50 to Account XXXX");
        System.out.println("Transfer successful.");
    }
}

public class main{
    public static void main(String[] args) {
        ATM atm = new ATM();
        atm.start();
    }
}
